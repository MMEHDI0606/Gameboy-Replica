#ifndef GAME_H
#define GAME_H

#include <SFML/Graphics.hpp>
#include <iostream>
#include "SoundSystem.h"

//using namespace sf;
using namespace std;

//// Forward declaration of SoundSystem
//class SoundSystem;

class Game {
public:
    //virtual is used for polymorphism with Gameboy.h
    virtual void startGame() = 0;
    virtual void endGame() = 0;
    virtual void render() = 0;
    void playsound(int x);
    void stopsound();
    
    SoundSystem soundSystem;
protected:
    char name[20];
    int score;
};

#endif
