#ifndef SOUNDSYSTEM_H
#define SOUNDSYSTEM_H

#include <SFML/Audio.hpp>
#include <iostream>
#include <string>
using namespace sf;
using namespace std;

class SoundSystem {
public:
    SoundSystem();
    void playSound(const string& filePath);
    void stopSound();
    void adjustVolume(int level);

private:
    int volume;
    SoundBuffer buffer;
    Sound sound;
};


inline SoundSystem::SoundSystem() {
    volume = 100; 
}

inline void SoundSystem::playSound(const string& filePath) {
    if (!buffer.loadFromFile(filePath)) {
        cerr << "Failed to load sound from " << filePath << endl;
        return;
    }
    sound.setBuffer(buffer);
    sound.setVolume(static_cast<float>(volume));
    sound.play();
}

inline void SoundSystem::stopSound() {
    sound.stop();
}
inline void SoundSystem::adjustVolume(int level) {
    if (level < 0) level = 0;
    if (level > 100) level = 100;
    volume = level;
    sound.setVolume(static_cast<float>(volume));
}

#endif 