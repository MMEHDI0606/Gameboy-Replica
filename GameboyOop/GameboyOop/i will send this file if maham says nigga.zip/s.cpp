//// SnakeGame.h and SnakeGame.cpp combined into a single file
//
//#include <SFML/Graphics.hpp>
//#include <iostream>
//#include <ctime>
//#include <sstream>
//
//using namespace sf;
//using namespace std;
//
//// Enum for snake direction
//enum Direction { UP, DOWN, LEFT, RIGHT };
//
//class SnakeGame {
//public:
//    SnakeGame();
//    void startGame();
//    void endGame();
//    void render();
//    void moveSnake();
//    void detectCollision();
//    void increaseDifficulty();
//    void updateDirection(Direction newDirection);
//    int speed; // Speed of the game (in milliseconds)
//
//private:
//    int snakeBody[100][2]; // Snake segment positions
//    int food[2]; // Food position
//    int gridWidth = 50; // Grid width
//    int gridHeight = 30; // Grid height
//    int snakeLength; // Length of the snake
//    Direction direction; // Current direction of the snake
//    RenderWindow window; // SFML window for rendering
//    RectangleShape headShape; // Shape for the head of the snake
//    RectangleShape bodyShape; // Shape for the body segments of the snake
//    RectangleShape tailShape; // Shape for the tail of the snake
//    RectangleShape foodShape; // Shape for the food
//    RectangleShape wallShape; // Shape for the walls
//    Texture backgroundTexture; // Texture for the background
//    Sprite backgroundSprite; // Sprite for the background
//    Font font; // Font for displaying text
//    Text scoreText; // Text for displaying the score
//    int score; // Score of the game
//};
//
//// Constructor for initializing the SnakeGame
//SnakeGame::SnakeGame() {
//    // Initialize snake starting position and grid
//    srand(static_cast<unsigned int>(time(nullptr))); // Seed for random food generation
//    snakeBody[0][0] = gridWidth / 2; // X position of head
//    snakeBody[0][1] = gridHeight / 2; // Y position of head
//    direction = RIGHT;
//    snakeLength = 5; // Initial length
//    food[0] = rand() % gridWidth; // X position of food
//    food[1] = rand() % gridHeight; // Y position of food
//    score = 0; // Initial score
//    speed = 200; // Initial speed in milliseconds
//
//    // Set up the shapes for rendering
//    headShape.setSize(Vector2f(20.0f, 20.0f));
//    headShape.setFillColor(Color::Green);
//
//    bodyShape.setSize(Vector2f(20.0f, 20.0f));
//    bodyShape.setFillColor(Color::Yellow);
//
//    tailShape.setSize(Vector2f(20.0f, 20.0f));
//    tailShape.setFillColor(Color::Red);
//
//    foodShape.setSize(Vector2f(20.0f, 20.0f));
//    foodShape.setFillColor(Color::Blue);
//
//    // Set up the walls
//    wallShape.setSize(Vector2f(20.0f, 20.0f));
//    wallShape.setFillColor(Color::White);
//
//    // Load background texture
//    if (!backgroundTexture.loadFromFile("../Sprite/background.png")) {
//        cout << "Failed to load background texture!" << endl;
//        return;
//    }
//    backgroundSprite.setTexture(backgroundTexture);
//
//    // Load font for score display
//    if (!font.loadFromFile("C:/Windows/Fonts/Gadugi.ttf")) {
//        cout << "Failed to load font!" << endl;
//        return;
//    }
//    scoreText.setFont(font);
//    scoreText.setCharacterSize(24);
//    scoreText.setFillColor(Color::Black);
//}
//
//// Start the Snake game
//void SnakeGame::startGame() {
//    cout << "Starting Snake Game..." << endl;
//    window.create(VideoMode(1000, 600), "Snake Game");
//}
//
//// End the Snake game
//void SnakeGame::endGame() {
//    cout << "Ending Snake Game..." << endl;
//    window.close();
//}
//
//// Render the game elements
//void SnakeGame::render() {
//    if (!window.isOpen()) {
//        return;
//    }
//
//    window.clear(Color::Black);
//
//    // Draw the background
//    window.draw(backgroundSprite);
//
//    // Draw the walls
//    for (int i = 0; i < gridWidth; ++i) {
//        // Top wall
//        wallShape.setPosition(i * 20, 0);
//        window.draw(wallShape);
//        // Bottom wall
//        wallShape.setPosition(i * 20, (gridHeight - 1) * 20);
//        window.draw(wallShape);
//    }
//    for (int i = 0; i < gridHeight; ++i) {
//        // Left wall
//        wallShape.setPosition(0, i * 20);
//        window.draw(wallShape);
//        // Right wall
//        wallShape.setPosition((gridWidth - 1) * 20, i * 20);
//        window.draw(wallShape);
//    }
//
//    // Draw the snake
//    for (int i = 0; i < snakeLength; ++i) {
//        if (i == 0) {
//            // Draw the head
//            headShape.setPosition(snakeBody[i][0] * 20, snakeBody[i][1] * 20);
//            window.draw(headShape);
//        }
//        else if (i == snakeLength - 1) {
//            // Draw the tail
//            tailShape.setPosition(snakeBody[i][0] * 20, snakeBody[i][1] * 20);
//            window.draw(tailShape);
//        }
//        else {
//            // Draw the body
//            bodyShape.setPosition(snakeBody[i][0] * 20, snakeBody[i][1] * 20);
//            window.draw(bodyShape);
//        }
//    }
//
//    // Draw the food
//    foodShape.setPosition(food[0] * 20, food[1] * 20);
//    window.draw(foodShape);
//
//    // Display the score
//    stringstream ss;
//    ss << "Score: " << score;
//    scoreText.setString(ss.str());
//    scoreText.setPosition(900, 20);
//    window.draw(scoreText);
//
//    window.display();
//}
//
//// Handle the snake movement
//void SnakeGame::moveSnake() {
//    // Move the body (from tail to head)
//    for (int i = snakeLength - 1; i > 0; --i) {
//        snakeBody[i][0] = snakeBody[i - 1][0];
//        snakeBody[i][1] = snakeBody[i - 1][1];
//    }
//
//    // Update the head based on direction
//    switch (direction) {
//    case UP:
//        snakeBody[0][1] -= 1;
//        break;
//    case DOWN:
//        snakeBody[0][1] += 1;
//        break;
//    case LEFT:
//        snakeBody[0][0] -= 1;
//        break;
//    case RIGHT:
//        snakeBody[0][0] += 1;
//        break;
//    }
//
//    detectCollision();
//}
//
//// Detect collisions for the snake
//void SnakeGame::detectCollision() {
//    // Handle collisions with the wall
//    if (snakeBody[0][0] <= 0 || snakeBody[0][0] >= gridWidth - 1 || snakeBody[0][1] <= 0 || snakeBody[0][1] >= gridHeight - 1) {
//        cout << "Game Over: Collision with wall!" << endl;
//        endGame();
//    }
//
//    // Handle collisions with itself
//    for (int i = 1; i < snakeLength; ++i) {
//        if (snakeBody[0][0] == snakeBody[i][0] && snakeBody[0][1] == snakeBody[i][1]) {
//            cout << "Game Over: Collision with self!" << endl;
//            endGame();
//        }
//    }
//
//    // Handle eating food
//    if (snakeBody[0][0] == food[0] && snakeBody[0][1] == food[1]) {
//        snakeLength++;
//        food[0] = rand() % (gridWidth - 2) + 1;
//        food[1] = rand() % (gridHeight - 2) + 1;
//        score += 10;
//
//        // Increase difficulty if score reaches 50
//        if (score % 50 == 0) {
//            increaseDifficulty();
//        }
//    }
//}
//
//// Increase the difficulty by making the snake move faster
//void SnakeGame::increaseDifficulty() {
//    if (speed > 50) { // Ensure the speed doesn't go too fast
//        speed -= 20;
//        cout << "Increasing difficulty. New speed: " << speed << "ms" << endl;
//    }
//}
//
//// Update the direction of the snake based on input
//void SnakeGame::updateDirection(Direction newDirection) {
//    // Prevent reversing direction
//    if ((direction == UP && newDirection != DOWN) ||
//        (direction == DOWN && newDirection != UP) ||
//        (direction == LEFT && newDirection != RIGHT) ||
//        (direction == RIGHT && newDirection != LEFT)) {
//        direction = newDirection;
//    }
//}
//
//int main() {
//    SnakeGame game;
//    game.startGame();
//
//    while (game.speed > 0) { // Ensures the game continues until speed becomes 0 or the window is closed
//        game.render();
//        game.moveSnake();
//
//        // Add delay for game speed control
//        sf::sleep(milliseconds(game.speed));
//
//        // Handle keyboard input
//        if (Keyboard::isKeyPressed(Keyboard::Up)) {
//            game.updateDirection(UP);
//        }
//        else if (Keyboard::isKeyPressed(Keyboard::Down)) {
//            game.updateDirection(DOWN);
//        }
//        else if (Keyboard::isKeyPressed(Keyboard::Left)) {
//            game.updateDirection(LEFT);
//        }
//        else if (Keyboard::isKeyPressed(Keyboard::Right)) {
//            game.updateDirection(RIGHT);
//        }
//    }
//
//    return 0;
//}
