#ifndef SNAKEGAME_H
#define SNAKEGAME_H

#include <SFML/Graphics.hpp>
#include <iostream>
#include <ctime>
#include <sstream>
#include "Game.h"

using namespace sf;
using namespace std;

// Enum for snake direction
enum Direction { UP, DOWN, LEFT, RIGHT };

class SnakeGame : public Game {
public:
    SnakeGame();
    void startGame() override;
    void endGame() override;
    void render() override;
    void moveSnake();
    void detectCollision();
    void increaseDifficulty();
    void updateDirection(Direction newDirection);
    int speed; // Speed of the game (in milliseconds)

private:
    int snakeBody[100][2]; // Snake segment positions
    int food[2]; // Food position
    int gridWidth = 50; // Grid width
    int gridHeight = 30; // Grid height
    int snakeLength; // Length of the snake
    Direction direction; // Current direction of the snake
    RenderWindow window; // SFML window for rendering
    RectangleShape headShape; // Shape for the head of the snake
    RectangleShape bodyShape; // Shape for the body segments of the snake
    RectangleShape tailShape; // Shape for the tail of the snake
    RectangleShape foodShape; // Shape for the food
    RectangleShape wallShape; // Shape for the walls
    Texture backgroundTexture; // Texture for the background
    Sprite backgroundSprite; // Sprite for the background
    Font font; // Font for displaying text
    Text scoreText; // Text for displaying the score
    int score; // Score of the game
};

#endif // SNAKEGAME_H
