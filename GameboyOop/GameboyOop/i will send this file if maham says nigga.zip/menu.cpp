#include "Menu.h"

Menu::Menu() {

    // Load background texture
    if (!backgroundTexture.loadFromFile("background.png")) {
        cerr << "Failed to load background texture!" << endl;
    }
    backgroundSprite.setTexture(backgroundTexture);


    // Load font
    if (!font.loadFromFile("C:/Windows/Fonts/Gadugi.ttf")) {
        cerr << "Failed to load font!" << endl;
    }

    // Title text
    titleText.setFont(font);
    titleText.setString("Gameboy Menu");
    titleText.setCharacterSize(48);
    titleText.setFillColor(Color::White);
    titleText.setPosition(300, 100);

    // Snake Game option
    snakeGameText.setFont(font);
    snakeGameText.setString("1. Snake Game");
    snakeGameText.setCharacterSize(36);
    snakeGameText.setFillColor(Color::White);
    snakeGameText.setPosition(350, 200);

    // Hangman Game option
    hangmanGameText.setFont(font);
    hangmanGameText.setString("2. Hangman Game");
    hangmanGameText.setCharacterSize(36);
    hangmanGameText.setFillColor(Color::White);
    hangmanGameText.setPosition(350, 300);

    // Wordle Game option
    wordleGameText.setFont(font);
    wordleGameText.setString("3. Wordle Game");
    wordleGameText.setCharacterSize(36);
    wordleGameText.setFillColor(Color::White);
    wordleGameText.setPosition(350, 400);
}

void Menu::render(RenderWindow& window) {
    window.draw(titleText);
    window.draw(snakeGameText);
    window.draw(hangmanGameText);
    window.draw(wordleGameText);
}

void Menu::handleInput(Event event, int& selectedGame) {
    if (event.type == Event::KeyPressed) {
        if (event.key.code == Keyboard::Num1) {
            selectedGame = 1; // Snake Game
        }
        else if (event.key.code == Keyboard::Num2) {
            selectedGame = 2; // Hangman Game
        }
        else if (event.key.code == Keyboard::Num3) {
            selectedGame = 3; // Wordle Game
        }
    }
}
