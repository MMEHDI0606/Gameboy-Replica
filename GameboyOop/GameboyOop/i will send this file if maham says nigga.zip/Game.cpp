#include "Game.h"
#include "SnakeGame.h"

void Game::startGame() {
    //empty since it is purely abstract
}

void Game::endGame() {
    //empty since it is purely abstract
}

void Game::render() {
    //empty since it is purely abstract
}
void Game::playsound(int x)
{
    while (x > 3 || x < 1)
    {
        cout << "Must be between 1 to 3";
        cin >> x;
    }
    switch (x)
    {
    case 1:
        soundSystem.playSound("../Sound/Snake.mp3");
        break;
    case 2:
        //play hangman
        soundSystem.playSound("../Sound/Hang.mp3");
    case 3:
        //play wordle
        soundSystem.playSound("../Sound/Wordle.mp3");
    default:
        break;
    }
}

void Game::stopsound()
{
    soundSystem.stopSound();
}