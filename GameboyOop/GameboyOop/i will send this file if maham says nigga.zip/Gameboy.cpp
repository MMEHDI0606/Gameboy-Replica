// Game.cpp - Implement random category and word selection logic
#include "GameBoy.h"
#include "Game.h"
#include "Category.h"
#include "HangmanGame.h"
#include "SnakeGame.h"
#include "WordleGame.h"
#include <iostream>
#include <cstdlib>
#include <ctime>

void selectRandomCategoryAndWord(Category& category, std::string& selectedWord) {
    int randomCategoryIndex = rand() % 3;
    const char oop_category[10][30] = { "inheritance", "polymorphism", "composition", "aggregation", "overloading", "overriding", "constructor", "destructor", "getter", "setter" };
    const char coal_category[10][30] = { "register", "memory", "cache", "address", "binary", "hexadecimal", "assembly", "stack", "offset", "masm" };
    const char discrete_category[10][30] = { "graphs", "proof", "traversal", "nodes", "edges", "trail", "walk", "path", "circuit", "combination" };
    const char* categoryNames[3] = { "OOP", "COAL", "DISCRETE" };

    // Set category name
    const char* selectedCategoryName = categoryNames[randomCategoryIndex];
    category = Category(selectedCategoryName);

    // Select a random word from the chosen category
    const char (*selectedWords)[30] = nullptr;
    switch (randomCategoryIndex) {
    case 0: selectedWords = oop_category; break;
    case 1: selectedWords = coal_category; break;
    case 2: selectedWords = discrete_category; break;
    }
    int randomWordIndex = rand() % 10;
    selectedWord = selectedWords[randomWordIndex];

    std::cout << "Category: " << category.getName() << std::endl;
    std::cout << "Selected Word: " << selectedWord << std::endl;
}

//GameBoy::GameBoy() {
//    // Set up window and initial game state
//    screen = new Screen(); // Allocate memory for screen (or replace with actual screen handling)
//    soundSystem = new SoundSystem();
//    currentGame = nullptr;
//}

GameBoy::~GameBoy() {
    // Clean up dynamically allocated memory
    delete screen;
    delete soundSystem;
}
void GameBoy::start() {
    RenderWindow window(VideoMode(1000, 800), "Gameboy");
    int selectedGame = 0;

    while (window.isOpen()) {
        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed) {
                shutdown();
                return;
            }

            if (currentGame == nullptr) {
                menu.handleInput(event, selectedGame);
            }
            else {
                if (event.type == Event::KeyPressed && event.key.code == sf::Keyboard::Escape) {
                    // Press escape to go back to menu
                    delete currentGame;
                    currentGame = nullptr;
                }
            }
        }

        if (selectedGame != 0 && currentGame == nullptr) {
            switch (selectedGame) {
            case 1:
                currentGame = new SnakeGame();
                break;
            case 2: {
                Category category;
                std::string selectedWord;
                selectRandomCategoryAndWord(category, selectedWord);
                currentGame = new HangmanGame(selectedWord.c_str(), category, 6);
                break;
            }
            case 3:
                currentGame = new WordleGame("MAHAM");
                break;
            default:
                selectedGame = 0;
                break;
            }

            if (currentGame != nullptr) {
                currentGame->startGame();
            }
        }

        window.clear();
        if (currentGame == nullptr) {
            menu.render(window);
        }
        else {
            currentGame->render();
        }
        window.display();
    }
}

void GameBoy::switchGame(Game* game) {
    if (currentGame != nullptr) {
        delete currentGame;
    }
    currentGame = game;
    if (currentGame) {
        currentGame->startGame();
    }
}

void GameBoy::shutdown() {
    if (currentGame) {
        currentGame->endGame();
        delete currentGame;
        currentGame = nullptr;
    }
}
