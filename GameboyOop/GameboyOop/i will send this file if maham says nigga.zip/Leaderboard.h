#ifndef LEADERBOARD_H
#define LEADERBOARD_H

#include <iostream>
#include "Player.h"
using namespace std;

class Leaderboard {
public:
    void updateScore(const Player* player, int score);
    void resetLeaderboard();
    void saveLeaderboard();
    void loadLeaderboard();

private:
    int highScores[10];
    Player* topPlayers[10]; 
};

#endif