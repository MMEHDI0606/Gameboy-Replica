#ifndef ACHIEVEMENTSYSTEM_H
#define ACHIEVEMENTSYSTEM_H

#include <iostream>
#include "Achievement.h"

using namespace std;

class AchievementSystem {
public:
    void trackAchievement(Achievement achievement);
    void updateProgress(int progress);

private:
    Achievement achievements[10]; // Using Achievement class to represent individual achievements
    int progress;
};

#endif
