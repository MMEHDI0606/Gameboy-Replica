#ifndef WORDLEGAME_H
#define WORDLEGAME_H

#include "Game.h"
#include "Keyboard.h"
#include "WordDictionary.h"
#include <SFML/Graphics.hpp>
#include <iostream>
#include <cstdlib>

using namespace std;

class WordleGame : public Game  {
private:
    static constexpr int gridRows = 6;
    static constexpr int gridCols = 5;
    char secretWord[gridCols + 1];          //The word we're trynna guess which in this case is MAHAM
    char grid[gridRows][gridCols];
    char feedback[gridRows][gridCols];       //to store the feedback (coloring the grid boxes)
    int attempts;
    Keyboard1 keyboard;
    WordDictionary dictionary;


    sf::RenderWindow window;        
    sf::Font font;                   
    sf::Texture backgroundTexture;    
    sf::Sprite backgroundSprite;      
    char currentGuess[gridCols + 1];  // Current guess that's typed in the row
    int currentLetter;                // Tracks the current letter being entered

    bool compareStrings(const char* str1, const char* str2) const {
        for (int i = 0; i < 6; ++i) {
            char c1 = (str1[i] >= 'a' && str1[i] <= 'z') ? str1[i] - ('a' - 'A') : str1[i];
            char c2 = (str2[i] >= 'a' && str2[i] <= 'z') ? str2[i] - ('a' - 'A') : str2[i];

            if (c1 != c2) return false;
            if (c1 == '\0') break; 
        }
        return true;
    }

public:
    WordleGame(const char* word) : attempts(0), currentLetter(0) {
        for (int i = 0; i < gridCols; ++i) {
            secretWord[i] = word[i];
        }
        secretWord[gridCols] = '\0';

        for (int i = 0; i < gridRows; ++i) {
            for (int j = 0; j < gridCols; ++j) {
                grid[i][j] = '\0';
                feedback[i][j] = '\0'; 
            }
        }

        for (int i = 0; i <= gridCols; ++i) {
            currentGuess[i] = '\0';
        }
    }

    sf::RenderWindow& getWindow() {
        return window;
    }

    static constexpr int getGridRows() { return gridRows; }
    static constexpr int getGridCols() { return gridCols; }
    int getAttempts() const { return attempts; }
    const char* getSecretWord() const { return secretWord; }
    Keyboard1& getKeyboard() { return keyboard; }

    void updateGrid(char letter, int row, int col) {
        grid[row][col] = letter; 
    }

    void clearRow(int row) {        //func to clear the row in case of invalid word
        for (int col = 0; col < gridCols; ++col) {
            grid[row][col] = '\0'; 
        }
    }

    void giveFeedback(const char* guess) {
        for (int i = 0; i < gridCols; ++i) {
            if (guess[i] == secretWord[i]) {
                feedback[attempts][i] = 'G';  // Correct letter
                keyboard.updateKey(guess[i], 'G');
            }
            else {
                bool found = false;
                for (int j = 0; j < gridCols; ++j) {
                    if (secretWord[j] == guess[i]) {
                        found = true;
                        break;
                    }
                }
                if (found) {
                    feedback[attempts][i] = 'Y';  // Present letter
                    keyboard.updateKey(guess[i], 'Y');
                }
                else {
                    feedback[attempts][i] = 'B';  // Incorrect letter
                    keyboard.updateKey(guess[i], 'B');
                }
            }
        }
        attempts++;
    }

    void draw(sf::RenderWindow& window, const sf::Font& font) {
        for (int i = 0; i < gridRows; ++i) {
            for (int j = 0; j < gridCols; ++j) {
                sf::RectangleShape rect(sf::Vector2f(60.f, 60.f));
                rect.setPosition(j * 70.f + 100.f, i * 70.f + 50.f);

                switch (feedback[i][j]) {
                case 'G': rect.setFillColor(sf::Color::Green); break;
                case 'Y': rect.setFillColor(sf::Color::Yellow); break;
                case 'B': rect.setFillColor(sf::Color(128, 128, 128)); break;
                default: rect.setFillColor(sf::Color::White); break;
                }

                window.draw(rect);

                if (grid[i][j] != '\0') {
                    sf::Text text;
                    text.setFont(font);
                    text.setString(grid[i][j]);
                    text.setCharacterSize(30);
                    text.setFillColor(sf::Color::Black);
                    text.setPosition(j * 70.f + 115.f, i * 70.f + 65.f);
                    window.draw(text);
                }
            }
        }
    }

    void handleCharacterInput(char inputChar) {
        if (inputChar >= 'a' && inputChar <= 'z') {
            inputChar = inputChar - ('a' - 'A');
        }

        if (currentLetter < gridCols) { 
            grid[attempts][currentLetter] = inputChar; 
            currentLetter++; // Move to the next position in the row
        }
    }


    void submitGuess() {
        if (currentLetter == gridCols) { // Only submit if the row is complete
            char guess[gridCols + 1];
            for (int i = 0; i < gridCols; ++i) {
                guess[i] = grid[attempts][i];
            }
            guess[gridCols] = '\0'; 
            if (dictionary.validateWord(guess)) { 
                //cout << "DEBUGGIN" << endl;
                giveFeedback(guess); 
                if (compareStrings(guess, secretWord)) {
                    cout << "YOU WINNNNNNNNNNN!" << endl;
                    //endGame();                I WANNA END IT BUT NOT IMMEDIATELY!!!
                }
            }
            else {
                cout << "Invalid word!" << endl;
                clearRow(attempts); 
            }

            currentLetter = 0;
        }
        else {
            cout << "Guess is incomplete!" << endl;
        }
    }

    void deleteLastCharacter() {
        if (currentLetter > 0) { 
            currentLetter--; 
            grid[attempts][currentLetter] = '\0'; 
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /*****************************************START, END, RENDER FUNCTIONS*********************************************************/
    void startGame() override {
        window.create(sf::VideoMode(900, 650), "Wordle Game");

        if (!font.loadFromFile("font.ttf")) {
            cerr << "Error loading font!" << endl;
            return;
        }

        if (!backgroundTexture.loadFromFile("wordle.jpg")) {
            cerr << "Error" << endl;
            return;
        }
        backgroundSprite.setTexture(backgroundTexture);

        backgroundSprite.setScale(
            static_cast<float>(window.getSize().x) / backgroundTexture.getSize().x,
            static_cast<float>(window.getSize().y) / backgroundTexture.getSize().y
        );

       // score = 0;
    }

    void endGame() override {
        cout << "Ending" << endl;
        if (window.isOpen()) {
            window.close();
        }
    }

    void render() override {
        if (!window.isOpen()) {
            return;
        }
        window.clear();
        window.draw(backgroundSprite);
        draw(window, font);          
        getKeyboard().draw(window, font); 
        window.display();
    }
};

#endif