// HangmanGame.cpp
#include "HangmanGame.h"
#include<sstream>
#include<iostream>
HangmanGame::HangmanGame(const char* word, const Category& category, int lives) : category(category) {
    this->lives = lives;
    this->streak = 0;
    // Copy word into `this->word`
    int i = 0;
    while (word[i] != '\0' && i < 9) {
        this->word[i] = word[i];
        i++;
    }
    this->word[i] = '\0';

    // Initialize `currentWord` with underscores and spaces
    for (int j = 0; j < i; j++) {
        currentWord[j] = (word[j] == ' ') ? ' ' : '_';
    }
    currentWord[i] = '\0';

    for (int k = 0; k < 26; k++) {
        guessedLetters[k] = false;  // By default, nothing is guessed
    }

    // Load the background texture
    if (!backgroundTexture.loadFromFile("background.png")) {
        std::cout << "Failed to load background texture!" << std::endl;
    }
    backgroundSprite.setTexture(backgroundTexture);

    // Load the font for text elements
    if (!font.loadFromFile("C:/Windows/Fonts/Gadugi.ttf")) {
        std::cout << "Failed to load font!" << std::endl;
    }

    // Initialize buttons and text elements
    initializeAlphabetButtons();
    initializeTextElements();
}

void HangmanGame::startGame() {
    std::cout << "Starting Hangman Game..." << std::endl;
    window.create(VideoMode(800, 600), "Hangman Game");
}

void HangmanGame::endGame() {
    std::cout << "Ending Hangman Game..." << std::endl;
    window.close();
}

void HangmanGame::render() {
    if (!window.isOpen()) {
        return;
    }

    window.clear(Color::Black);

    // Draw the background
    window.draw(backgroundSprite);

    // Draw the alphabet buttons
    for (int i = 0; i < 26; ++i) {
        window.draw(alphabetButtons[i]);
        window.draw(alphabetText[i]);
    }

    // Draw the word display
    wordDisplay.setString(getCurrentWordDisplay());
    window.draw(wordDisplay);

    // Update stats display
    stringstream ss;
    ss << "Lives: " << getLives() << "\nStreak: " << getStreak();
    statsDisplay.setString(ss.str());
    window.draw(statsDisplay);

    // Draw the hint button and hint text
    window.draw(hintButton);
    window.draw(hintText);

    // Draw the hangman figure
    drawHangman(window);

    window.display();
}

void HangmanGame::handleInput() {
    Event event;
    while (window.pollEvent(event)) {
        if (event.type == Event::Closed) {
            endGame();
        }

        if (event.type == Event::MouseButtonPressed) {
            Vector2i mousePos = Mouse::getPosition(window);

            // Check if any alphabet button is pressed
            for (int i = 0; i < 26; ++i) {
                if (alphabetButtons[i].getGlobalBounds().contains(mousePos.x, mousePos.y)) {
                    char guessedLetter = alphabet[i];
                    trackGuesses(guessedLetter);
                    alphabetButtons[i].setFillColor(Color::Red); // Disable button
                    break;
                }
            }

            // Check if hint button is pressed
            if (hintButton.getGlobalBounds().contains(mousePos.x, mousePos.y)) {
                revealLetter();
            }
        }
    }
}

void HangmanGame::trackGuesses(char guess) {
    if (guessedLetters[guess - 'A']) {
        cout << "Letter already guessed!\n";
        return;
    }

    guessedLetters[guess - 'A'] = true;
    bool found = false;

    // Check if guess is in the word
    for (int i = 0; word[i] != '\0'; i++) {
        if (toupper(word[i]) == guess) {
            currentWord[i] = word[i];
            found = true;
        }
    }

    // Update streak based on correctness
    manageStreak(found);

    // Manage lives
    manageLives(found);
}

void HangmanGame::manageLives(bool isCorrect) {
    if (!isCorrect) {
        lives--;
    }
}

bool HangmanGame::isGuessCorrect(char guess) const {
    for (int i = 0; word[i] != '\0'; i++) {
        if (toupper(word[i]) == guess) {
            return true;
        }
    }
    return false;
}

bool HangmanGame::isWordGuessed() const {
    for (int i = 0; word[i] != '\0'; i++) {
        if (word[i] != currentWord[i]) {
            return false;
        }
    }
    return true;
}

int HangmanGame::getLives() const {
    return lives;
}

int HangmanGame::getStreak() const {
    return streak;
}

const char* HangmanGame::getCurrentWordDisplay() const {
    return currentWord;
}

const char* HangmanGame::getWord() const {
    return word;
}

void HangmanGame::revealLetter() {
    for (int i = 0; word[i] != '\0'; i++) {
        if (currentWord[i] == '_' && !guessedLetters[toupper(word[i]) - 'A']) {
            // Reveal the letter in currentWord
            char revealedLetter = toupper(word[i]);
            for (int j = 0; word[j] != '\0'; j++) {
                if (toupper(word[j]) == revealedLetter) {
                    currentWord[j] = word[j];
                }
            }

            // Mark the letter as guessed
            guessedLetters[revealedLetter - 'A'] = true;
            cout << "Hint revealed letter: " << revealedLetter << "\n";
            return;
        }
    }
    cout << "No more letters to reveal!\n";
}

void HangmanGame::manageStreak(bool isCorrect) {
    if (isCorrect) {
        streak++;
        cout << "Streak increased! Current streak: " << streak << "\n";
    }
    else {
        streak = 0;
        cout << "Streak reset! Current streak: " << streak << "\n";
    }
}

void HangmanGame::drawHangman(sf::RenderWindow& window) {
    hangmanFigure.draw(window, lives); // Delegate to HangmanFigure
}

void HangmanGame::initializeAlphabetButtons() {
    float buttonRadius = 20.0f;
    float startX = 100.0f;
    float startY = 400.0f;
    float offsetX = 50.0f;
    float offsetY = 50.0f;

    for (int i = 0; i < 26; ++i) {
        alphabetButtons[i].setRadius(buttonRadius);
        alphabetButtons[i].setFillColor(Color::White);
        alphabetButtons[i].setOutlineColor(Color::Black);
        alphabetButtons[i].setOutlineThickness(2);

        int row = i / 13;
        int col = i % 13;
        alphabetButtons[i].setPosition(startX + col * offsetX, startY + row * offsetY);

        alphabet[i] = 'A' + i;

        alphabetText[i].setFont(font);
        alphabetText[i].setString(std::string(1, alphabet[i]));
        alphabetText[i].setCharacterSize(24);
        alphabetText[i].setFillColor(Color::Black);
        alphabetText[i].setPosition(alphabetButtons[i].getPosition().x + buttonRadius / 2,
            alphabetButtons[i].getPosition().y + buttonRadius / 4);
    }
}

void HangmanGame::initializeTextElements() {
    // Set up the word display
    wordDisplay.setFont(font);
    wordDisplay.setCharacterSize(32);
    wordDisplay.setFillColor(Color::Black);
    wordDisplay.setPosition(100, 100);
    wordDisplay.setString(getCurrentWordDisplay());

    // Set up the stats display (lives and streak)
    statsDisplay.setFont(font);
    statsDisplay.setCharacterSize(24);
    statsDisplay.setFillColor(Color::Black);
    statsDisplay.setPosition(100, 150);
    std::stringstream ss;
    ss << "Lives: " << getLives() << "    Streak: " << getStreak();
    statsDisplay.setString(ss.str());

    // Set up the hint button
    hintButton.setSize(Vector2f(100, 50));
    hintButton.setFillColor(Color::Yellow);
    hintButton.setPosition(600, 500);

    // Set up the hint text
    hintText.setFont(font);
    hintText.setCharacterSize(20);
    hintText.setFillColor(Color::Black);
    hintText.setString("Hint");
    hintText.setPosition(hintButton.getPosition().x + 25, hintButton.getPosition().y + 10);
}
