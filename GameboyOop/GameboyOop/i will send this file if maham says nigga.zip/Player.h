#ifndef PLAYER_H
#define PLAYER_H

#include <iostream>
#include "Achievement.h"

using namespace std;

class Player {
public:
    void saveProgress();
    void loadProgress();

private:
    char name[20];
    Achievement achievements[10];
    int highScores[3];
    char currentGameState[20];
};

#endif
