#ifndef GAMEBOY_H
#define GAMEBOY_H

#include "Menu.h"
#include "Screen.h"
#include "InputSystem.h"
#include "SoundSystem.h"
#include "Game.h"
#include "Player.h"
#include <SFML/Graphics.hpp>
#include <iostream>

using namespace sf;
using namespace std;

class GameBoy {
public:
    void start();
    void switchGame(Game* game);
    void shutdown();

private:
    Player player; // Composed - GameBoy owns Player, responsible for its lifecycle
    Game* currentGame; // Composed - GameBoy owns currentGame, responsible for its lifecycle
    Menu menu; // Composed - GameBoy owns Menu, responsible for its lifecycle

    // Aggregated - Screen, InputSystem, and SoundSystem are not owned by GameBoy
    Screen* screen;
    InputSystem* inputSystem;
    SoundSystem* soundSystem;
};

#endif
