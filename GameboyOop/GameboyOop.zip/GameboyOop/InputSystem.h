#ifndef INPUTSYSTEM_H
#define INPUTSYSTEM_H

#include <SFML/Graphics.hpp>
#include <iostream>

using namespace sf;
using namespace std;

class InputSystem {
public:
    void mapKey(const char* key, const char* action);
    void handleInput();

private:
    char keyMappings[10][2]; //2d array , ith index is the key and jth index is the action with it
    char inputState[10];//size [10] indicates that it can manage up to 10 different keys
};

#endif