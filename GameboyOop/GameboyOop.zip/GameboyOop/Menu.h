#ifndef MENU_H
#define MENU_H

#include <SFML/Graphics.hpp>
#include <iostream>

using namespace sf;
using namespace std;

class Menu {
public:
    void navigate(const char* option);
    void transition(const char* nextState);

private:
    char menuOptions[5][20]; // 5 menu options with 20 characters max
    char state[20]; // menu state e.g main menu, setting etc
};

#endif