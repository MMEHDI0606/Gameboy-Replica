#include "Game.h"
#include "SnakeGame.h"

void Game::startGame() {
    //empty since it is purely abstract
}

void Game::endGame() {
    //empty since it is purely abstract
}

void Game::render() {
    //empty since it is purely abstract
}
