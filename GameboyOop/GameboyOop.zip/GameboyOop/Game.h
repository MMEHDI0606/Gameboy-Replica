#ifndef GAME_H
#define GAME_H

#include <SFML/Graphics.hpp>
#include <iostream>
#include "SoundSystem.h"
using namespace sf;
using namespace std;

class Game {
public:
    //virtual is used for polymorphism with Gameboy.h
    virtual void startGame() = 0;
    virtual void endGame() = 0;
    virtual void render() = 0;

    SoundSystem S;
    void playsound(int x)
    {
        while (x > 3 || x < 1)
        {
            cout << "Must be between 1 to 3";
            cin >> x;
        }
        switch (x)
        {
        case 1:
            S.playSound("../Sound/Snake.mp3");
            break;
        case 2:
            //play hangman
            S.playSound("../Sound/Hang.mp3");
        case 3:
            //play wordle
            S.playSound("../Sound/Wordle.mp3");
        default:
            break;
        }
    }

    void stopsound()
    {
        S.stopSound();
    }
protected:
    char name[20];
    int score;
};

#endif
